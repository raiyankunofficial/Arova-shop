
import os
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "CHANGE_THIS_SECRET_KEY")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "arova.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024

db = SQLAlchemy(app)

# Change these before publishing:
ADMIN_EMAIL = os.environ.get("AROVA_ADMIN_EMAIL", "admin@arova.com").lower().strip()
ADMIN_PASSWORD = os.environ.get("AROVA_ADMIN_PASSWORD", "ChangeMe123!")

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif"}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(40), default="")
    address = db.Column(db.Text, default="")
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    orders = db.relationship("Order", backref="user", lazy=True, cascade="all, delete-orphan")

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    category = db.Column(db.String(100), nullable=False, index=True)
    description = db.Column(db.Text, default="")
    price = db.Column(db.Float, nullable=False, default=0)
    sale_price = db.Column(db.Float, nullable=True)
    image = db.Column(db.String(255), default="")
    stock = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def current_price(self):
        return self.sale_price if self.sale_price is not None and self.sale_price < self.price else self.price

    @property
    def discount_percent(self):
        if self.sale_price is None or self.sale_price >= self.price or self.price <= 0:
            return 0
        return round((self.price - self.sale_price) / self.price * 100)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    total = db.Column(db.Float, nullable=False, default=0)
    status = db.Column(db.String(40), default="Pending")
    customer_name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(40), nullable=False)
    address = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship("OrderItem", backref="order", lazy=True, cascade="all, delete-orphan")

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    product_name = db.Column(db.String(180), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    unit_price = db.Column(db.Float, nullable=False)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

@app.context_processor
def inject_globals():
    cart = session.get("cart", {})
    cart_count = sum(int(v) for v in cart.values())
    return {
        "current_user_obj": current_user(),
        "cart_count": cart_count,
        "arova_name": "Arova",
    }

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Please login first.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user or not user.is_admin:
            flash("Admin access required.", "danger")
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)
    return wrapped

def seed():
    db.create_all()
    # Create the admin account from environment settings.
    admin = User.query.filter_by(email=ADMIN_EMAIL).first()
    if not admin:
        admin = User(
            name="Arova Admin",
            email=ADMIN_EMAIL,
            password_hash=generate_password_hash(ADMIN_PASSWORD),
            is_admin=True,
        )
        db.session.add(admin)
    elif not admin.is_admin:
        admin.is_admin = True

    if Product.query.count() == 0:
        demo = [
            ("Arova Essential Tee", "T-Shirts", "Premium everyday cotton T-shirt.", 850, 699, "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80", 30),
            ("Arova Classic Set", "Three Piece", "Minimal premium three-piece collection.", 1850, 1590, "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=900&q=80", 20),
            ("Arova Oversized Black", "Oversized", "Heavy GSM oversized black tee.", 1100, None, "https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=900&q=80", 25),
            ("Arova Premium Trouser", "Trousers", "Relaxed premium trouser.", 1450, 1250, "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=900&q=80", 18),
        ]
        for name, cat, desc, price, sale, image, stock in demo:
            db.session.add(Product(name=name, category=cat, description=desc,
                                   price=price, sale_price=sale, image=image, stock=stock))
    db.session.commit()

@app.route("/")
def home():
    products = Product.query.filter_by(active=True).order_by(Product.created_at.desc()).limit(8).all()
    categories = db.session.query(Product.category).filter(Product.active.is_(True)).distinct().all()
    categories = [x[0] for x in categories]
    return render_template("home.html", products=products, categories=categories)

@app.route("/shop")
def shop():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    stmt = Product.query.filter_by(active=True)
    if q:
        stmt = stmt.filter(db.or_(Product.name.ilike(f"%{q}%"), Product.description.ilike(f"%{q}%")))
    if category:
        stmt = stmt.filter_by(category=category)
    products = stmt.order_by(Product.created_at.desc()).all()
    categories = [x[0] for x in db.session.query(Product.category).filter(Product.active.is_(True)).distinct().all()]
    return render_template("shop.html", products=products, categories=categories, q=q, category=category)

@app.route("/product/<int:product_id>")
def product_detail(product_id):
    product = db.get_or_404(Product, product_id)
    if not product.active:
        return "Product unavailable", 404
    return render_template("product.html", product=product)

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        if User.query.filter_by(email=email).first():
            flash("Email already registered.", "danger")
            return redirect(url_for("signup"))
        user = User(name=name, email=email, password_hash=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        session["user_id"] = user.id
        flash("Account created successfully.", "success")
        return redirect(url_for("account"))
    return render_template("auth.html", mode="signup")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        user = User.query.filter_by(email=email).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash("Invalid email or password.", "danger")
            return redirect(url_for("login"))
        session["user_id"] = user.id
        next_url = request.args.get("next") or url_for("account")
        return redirect(next_url)
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.pop("user_id", None)
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))

@app.route("/account", methods=["GET", "POST"])
@login_required
def account():
    user = current_user()
    if request.method == "POST":
        user.name = request.form["name"].strip()
        user.phone = request.form.get("phone", "").strip()
        user.address = request.form.get("address", "").strip()
        db.session.commit()
        flash("Account updated.", "success")
        return redirect(url_for("account"))
    orders = Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).all()
    return render_template("account.html", user=user, orders=orders)

@app.route("/cart")
def cart():
    cart_data = session.get("cart", {})
    items, total = [], 0
    for pid, qty in cart_data.items():
        product = db.session.get(Product, int(pid))
        if not product or not product.active:
            continue
        qty = max(1, int(qty))
        subtotal = product.current_price * qty
        total += subtotal
        items.append({"product": product, "qty": qty, "subtotal": subtotal})
    return render_template("cart.html", items=items, total=total)

@app.post("/cart/add/<int:product_id>")
def add_to_cart(product_id):
    product = db.get_or_404(Product, product_id)
    if not product.active:
        flash("Product unavailable.", "danger")
        return redirect(url_for("shop"))
    cart = session.get("cart", {})
    key = str(product_id)
    cart[key] = min(int(cart.get(key, 0)) + int(request.form.get("qty", 1)), max(1, product.stock))
    session["cart"] = cart
    flash("Added to cart.", "success")
    return redirect(request.referrer or url_for("shop"))

@app.post("/cart/update")
def update_cart():
    cart = session.get("cart", {})
    for key in list(cart.keys()):
        qty = int(request.form.get(f"qty_{key}", 0))
        product = db.session.get(Product, int(key))
        if not product or qty <= 0:
            cart.pop(key, None)
        else:
            cart[key] = min(qty, max(1, product.stock))
    session["cart"] = cart
    flash("Cart updated.", "success")
    return redirect(url_for("cart"))

@app.get("/cart/remove/<int:product_id>")
def remove_cart(product_id):
    cart = session.get("cart", {})
    cart.pop(str(product_id), None)
    session["cart"] = cart
    return redirect(url_for("cart"))

@app.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    cart_data = session.get("cart", {})
    items, total = [], 0
    for pid, qty in cart_data.items():
        product = db.session.get(Product, int(pid))
        if product and product.active and product.stock > 0:
            qty = min(int(qty), product.stock)
            items.append((product, qty))
            total += product.current_price * qty
    if not items:
        flash("Your cart is empty.", "warning")
        return redirect(url_for("cart"))

    user = current_user()
    if request.method == "POST":
        name = request.form["name"].strip()
        phone = request.form["phone"].strip()
        address = request.form["address"].strip()
        if not name or not phone or not address:
            flash("Please fill in all delivery fields.", "danger")
            return redirect(url_for("checkout"))

        order = Order(user_id=user.id, total=total, customer_name=name, phone=phone, address=address)
        db.session.add(order)
        db.session.flush()
        for product, qty in items:
            db.session.add(OrderItem(order_id=order.id, product_id=product.id,
                                     product_name=product.name, quantity=qty,
                                     unit_price=product.current_price))
            product.stock -= qty
        db.session.commit()
        session["cart"] = {}
        flash(f"Order #{order.id} placed successfully.", "success")
        return redirect(url_for("account"))
    return render_template("checkout.html", items=items, total=total, user=user)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        user = User.query.filter_by(email=email, is_admin=True).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash("Invalid admin credentials.", "danger")
            return redirect(url_for("admin_login"))
        if not check_password_hash(user.password_hash, password):
            flash("Invalid admin credentials.", "danger")
            return redirect(url_for("admin_login"))
        session["user_id"] = user.id
        return redirect(url_for("admin_dashboard"))
    return render_template("admin_login.html")

@app.route("/admin")
@admin_required
def admin_dashboard():
    products = Product.query.order_by(Product.created_at.desc()).all()
    orders = Order.query.order_by(Order.created_at.desc()).all()
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin.html", products=products, orders=orders, users=users)

@app.post("/admin/product/add")
@admin_required
def admin_add_product():
    image_url = request.form.get("image_url", "").strip()
    image = image_url
    file = request.files.get("image_file")
    if file and file.filename and allowed_file(file.filename):
        filename = secure_filename(f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{file.filename}")
        file.save(os.path.join(UPLOAD_DIR, filename))
        image = "/static/uploads/" + filename

    product = Product(
        name=request.form["name"].strip(),
        category=request.form["category"].strip(),
        description=request.form.get("description", "").strip(),
        price=float(request.form["price"]),
        sale_price=float(request.form["sale_price"]) if request.form.get("sale_price") else None,
        image=image,
        stock=int(request.form.get("stock", 0)),
        active=True
    )
    db.session.add(product)
    db.session.commit()
    flash("Product added.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/admin/product/<int:product_id>/edit")
@admin_required
def admin_edit_product(product_id):
    product = db.get_or_404(Product, product_id)
    product.name = request.form["name"].strip()
    product.category = request.form["category"].strip()
    product.description = request.form.get("description", "").strip()
    product.price = float(request.form["price"])
    product.sale_price = float(request.form["sale_price"]) if request.form.get("sale_price") else None
    product.stock = int(request.form.get("stock", 0))
    product.active = bool(request.form.get("active"))
    if request.form.get("image_url"):
        product.image = request.form["image_url"].strip()
    file = request.files.get("image_file")
    if file and file.filename and allowed_file(file.filename):
        filename = secure_filename(f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{file.filename}")
        file.save(os.path.join(UPLOAD_DIR, filename))
        product.image = "/static/uploads/" + filename
    db.session.commit()
    flash("Product updated.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/admin/product/<int:product_id>/delete")
@admin_required
def admin_delete_product(product_id):
    product = db.get_or_404(Product, product_id)
    db.session.delete(product)
    db.session.commit()
    flash("Product deleted.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/admin/order/<int:order_id>/status")
@admin_required
def admin_order_status(order_id):
    order = db.get_or_404(Order, order_id)
    order.status = request.form["status"]
    db.session.commit()
    flash("Order status updated.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/admin/user/<int:user_id>/delete")
@admin_required
def admin_delete_user(user_id):
    user = db.get_or_404(User, user_id)
    if user.is_admin:
        flash("Admin account cannot be deleted here.", "danger")
    else:
        db.session.delete(user)
        db.session.commit()
        flash("Customer deleted.", "success")
    return redirect(url_for("admin_dashboard"))

@app.get("/api/products")
def api_products():
    products = Product.query.filter_by(active=True).all()
    return jsonify([{
        "id": p.id, "name": p.name, "category": p.category,
        "price": p.price, "sale_price": p.sale_price,
        "current_price": p.current_price, "stock": p.stock,
        "image": p.image
    } for p in products])

@app.cli.command("reset-admin-password")
def reset_admin_password():
    admin = User.query.filter_by(email=ADMIN_EMAIL).first()
    if not admin:
        print("Admin account not found. Run the app once first.")
        return
    new_password = input("New admin password: ").strip()
    admin.password_hash = generate_password_hash(new_password)
    db.session.commit()
    print("Admin password changed.")

with app.app_context():
    seed()

if __name__ == "__main__":
    app.run(debug=True)

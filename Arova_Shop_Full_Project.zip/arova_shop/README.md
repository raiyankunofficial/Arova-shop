
# Arova Shop — Flask E-commerce Starter

## Features
- Premium black/white Arova storefront
- Responsive mobile-first layout
- Product categories, search, product details
- Customer signup/login/logout
- Account management and order history
- Session cart and checkout
- SQLite database
- Admin Gmail/email + password login
- Admin product add/edit/delete
- Change regular price and sale price
- Stock management
- Product image URL or local image upload
- Active/inactive products
- Order status management
- Customer management

## Run locally

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Set admin credentials before publishing.

Windows PowerShell:
`$env:AROVA_ADMIN_EMAIL="youradmin@gmail.com"`
`$env:AROVA_ADMIN_PASSWORD="a-strong-password"`

Linux/macOS:
`export AROVA_ADMIN_EMAIL="youradmin@gmail.com"`
`export AROVA_ADMIN_PASSWORD="a-strong-password"`

Also set a random SECRET_KEY:
`export SECRET_KEY="replace-with-a-long-random-secret"`

5. Start:
   `python app.py`

6. Open:
   `http://127.0.0.1:5000`

Admin:
`http://127.0.0.1:5000/admin/login`

## Important production notes
- Do NOT publish with the sample admin password.
- Use HTTPS in production.
- Use a real random SECRET_KEY.
- For a large store, move from SQLite to PostgreSQL/MySQL. SQLite is convenient for small apps but concurrent writes can become a bottleneck.
- The current admin login uses an email address + password. It is not Google OAuth. If you want a real "Sign in with Google" button, create Google OAuth credentials and add OAuth routes separately.
- Payment gateways (bKash/Nagad/card) need the credentials/API details from the selected payment provider. This starter creates the order flow but does not fake a successful payment.
